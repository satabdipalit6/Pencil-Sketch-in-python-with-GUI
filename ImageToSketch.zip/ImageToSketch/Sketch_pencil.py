import tkinter
from tkinter import *
import qrcode as qr
from PIL import Image,ImageTk
from resizeimage import resizeimage
import cv2
from tkinter import filedialog
# from tkinter.filedialog import asksaveasfile

class Sketch_Generation:
  def __init__(self,root):
      self.root=root
      self.root.geometry("900x500+200+50")
      self.root.title("Pencil Sketch Generator|| Developed By CSE,BEST")
      self.root.resizable(False,False)
      self.root.configure(bg='#00FFFF')
      
      title=Label(text="Pencil Sketch Generator", font=("times new roman",40),bg="#8B008B").place(x=0,y=0,relwidth=1)
      self.filepath=None

      #----------------------------- Sketch Generator Window----------------------#
      app_window =Frame(self.root,bd=2,relief=RIDGE,bg='white')   
      app_window.place(x=190,y=80,width=480,height=400) 
      upload_btn=Button(app_window,text="Upload Original Image",command=self.upload,font=("times new roman",15,'bold'),bg='yellow').place(x=160,y=0,width=200)
      
      
      
      btn_generate=Button(app_window,text="Sketch Generate",command=self.sketch,font=("Times new roman",18,'bold'),bg='#0EF78A').place(x=50,y=150,width=200)
      btn_clear=Button(app_window,text="Clear",command=self.clear,font=("Times new roman",18,'bold'),bg='#0EF78A').place(x=280,y=150,width=150)
      
      self.msg=''
      self.lbl_msg=Label(app_window,text=self.msg,font=("times new roman",15,'bold'),bg='white',fg='#000080')
      self.lbl_msg.place(x=20,y=210,relwidth=1) 
      
      save_btn= Button(app_window, text= "Save", command=self.save_file,font=("times new roman",18,'bold'),bg='#4D37DB').place(x=140,y=300,width=200)
    

 #-------------------------------Upload Files---------------# 
  def upload(self):
      self.filepath=filedialog.askopenfilename()
      self.original_img=cv2.imread(self.filepath)
      cv2.imshow('Original Image',self.original_img)
      return self.original_img,self.filepath
    
  #------------------------------Sketch Generator---------------# 
  def sketch(self):
      gr=cv2.cvtColor(self.original_img,cv2.COLOR_BGR2GRAY)
      # cv2.imshow('Original Image',gr)
      invert=cv2.bitwise_not(gr)
      blur=cv2.GaussianBlur(invert,(21,21),0)
      invertedblur=cv2.bitwise_not(blur)
      sketch=cv2.divide(gr,invertedblur,scale=256.0)
      cv2.imshow('Final',sketch)
      self.msg='Sketch Completed Successfully!!!'
      self.lbl_msg.config(text=self.msg,fg='green')
      self.sketch=sketch
      return self.sketch
      
      
      
      
  def clear(self):
      cv2.destroyAllWindows()
      self.msg=''
      self.lbl_msg.config(text=self.msg)
      
  def save_file(self):
         status = cv2.imwrite(str(self.filepath)+'.png',self.sketch)
         self.msg='Sketch Saved Successfully!!!'
         self.lbl_msg.config(text=self.msg,fg='RED')
        
        
     
      
      
           
root=Tk()
obj=Sketch_Generation(root)
root.mainloop()
      